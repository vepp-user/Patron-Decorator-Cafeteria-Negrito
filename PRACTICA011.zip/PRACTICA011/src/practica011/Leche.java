package practica011;
public class Leche extends ComplementoDecorator {

    private Cafe cafe;

    public Leche(Cafe cafe) {
        this.cafe = cafe;
    }

    @Override
    public String getDescripcion() {
        return cafe.getDescripcion() + ", Leche";
    }

    @Override
    public double costo() {
        return cafe.costo() + 0.10;
    }
}
