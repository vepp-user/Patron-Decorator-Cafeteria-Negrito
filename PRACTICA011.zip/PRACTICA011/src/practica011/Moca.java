package practica011;
public class Moca extends ComplementoDecorator {

    private Cafe cafe;

    public Moca(Cafe cafe) {
        this.cafe = cafe;
    }

    @Override
    public String getDescripcion() {
        return cafe.getDescripcion() + ", Moca";
    }

    @Override
    public double costo() {
        return cafe.costo() + 0.20;
    }
}
