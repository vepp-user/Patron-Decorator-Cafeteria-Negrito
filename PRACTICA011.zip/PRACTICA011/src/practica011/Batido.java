package practica011;
public class Batido extends Cafe {

    public Batido() {
        descripcion = "Cafe Batido";
    }

    @Override
    public double costo() {
        return 0.89;
    }
}
