package practica011;
public class Crema extends ComplementoDecorator {

    private Cafe cafe;

    public Crema(Cafe cafe) {
        this.cafe = cafe;
    }

    @Override
    public String getDescripcion() {
        return cafe.getDescripcion() + ", Crema";
    }

    @Override
    public double costo() {
        return cafe.costo() + 0.10;
    }
}
