package practica011;
public abstract class ComplementoDecorator extends Cafe {

    @Override
    public abstract String getDescripcion();
}