package practica011;
public abstract class Cafe {

    protected String descripcion = "Cafe";

    public String getDescripcion() {
        return descripcion;
    }

    public abstract double costo();
}
