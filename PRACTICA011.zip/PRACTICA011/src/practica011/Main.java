package practica011;
public class Main {

    public static void main(String[] args) {

        System.out.println("BIENVENIDO A CAFETERIA NEGRITO");
        System.out.println();

        Cafe bebida = new Expreso();

        System.out.println("Su orden: " + bebida.getDescripcion());
        System.out.println("Total: $ " + bebida.costo());

        System.out.println();

        Cafe bebida2 = new TostadoNegro();
        bebida2 = new Moca(bebida2);
        bebida2 = new Crema(bebida2);

        System.out.println("Su orden: " + bebida2.getDescripcion());
        System.out.println("Total: $ " + bebida2.costo());

        System.out.println();

        Cafe bebida3 = new Batido();
        bebida3 = new Soya(bebida3);
        bebida3 = new Moca(bebida3);
        bebida3 = new Moca(bebida3);
        bebida3 = new Crema(bebida3);

        System.out.println("Su orden: " + bebida3.getDescripcion());
        System.out.println("Total: $ " + bebida3.costo());

        System.out.println();

        Cafe bebida4 = new Descafeinado();
        bebida4 = new Leche(bebida4);
        bebida4 = new Moca(bebida4);
        bebida4 = new Crema(bebida4);
        bebida4 = new Soya(bebida4);

        System.out.println("Su orden: " + bebida4.getDescripcion());
        System.out.println("Total: $ " + bebida4.costo());
    }
}
