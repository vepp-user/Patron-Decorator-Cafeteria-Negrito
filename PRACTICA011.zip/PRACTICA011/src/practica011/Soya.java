package practica011;
public class Soya extends ComplementoDecorator {

    private Cafe cafe;

    public Soya(Cafe cafe) {
        this.cafe = cafe;
    }

    @Override
    public String getDescripcion() {
        return cafe.getDescripcion() + ", Soya";
    }

    @Override
    public double costo() {
        return cafe.costo() + 0.15;
    }
}
