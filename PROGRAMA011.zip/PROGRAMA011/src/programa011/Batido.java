package programa011;
public class Batido extends Cafe {

    public Batido() {
        descripcion = "Cafe Batido";
    }

    @Override
    public double costo() {

        switch (tamano) {

            case MEDIANO:
                return 0.99;

            case GRANDE:
                return 1.09;

            default:
                return 0.89;
        }
    }
}
