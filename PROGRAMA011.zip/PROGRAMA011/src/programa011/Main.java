package programa011;
public class Main {

    public static void main(String[] args) {

        System.out.println("BIENVENIDO A CAFETERIA NEGRITO");
        System.out.println();

        Cafe bebida1 = new Expreso();
        bebida1.setTamano(Tamano.NORMAL);

        System.out.println("Su orden: " + bebida1.getDescripcion());
        System.out.println("Tamano: " + bebida1.getTamano());
        System.out.println("Total: $" + bebida1.costo());

        System.out.println();

        Cafe bebida2 = new TostadoNegro();
        bebida2.setTamano(Tamano.MEDIANO);

        bebida2 = new Moca(bebida2);
        bebida2 = new Crema(bebida2);

        System.out.println("Su orden: " + bebida2.getDescripcion());
        System.out.println("Tamano: " + bebida2.getTamano());
        System.out.println("Total: $" + bebida2.costo());

        System.out.println();

        Cafe bebida3 = new Batido();
        bebida3.setTamano(Tamano.GRANDE);

        bebida3 = new Soya(bebida3);
        bebida3 = new Moca(bebida3);

        System.out.println("Su orden: " + bebida3.getDescripcion());
        System.out.println("Tamano: " + bebida3.getTamano());
        System.out.println("Total: $" + bebida3.costo());
    }
}