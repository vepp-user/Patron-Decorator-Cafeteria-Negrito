package programa011;
public class Expreso extends Cafe {

    public Expreso() {
        descripcion = "Cafe Expreso";
    }

    @Override
    public double costo() {

        switch (tamano) {

            case MEDIANO:
                return 2.09;

            case GRANDE:
                return 2.15;

            default:
                return 1.99;
        }
    }
}