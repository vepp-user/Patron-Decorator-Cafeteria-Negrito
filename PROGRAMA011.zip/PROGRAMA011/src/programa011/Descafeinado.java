package programa011;
public class Descafeinado extends Cafe {

    public Descafeinado() {
        descripcion = "Cafe Descafeinado";
    }

    @Override
    public double costo() {

        switch (tamano) {

            case MEDIANO:
                return 1.15;

            case GRANDE:
                return 1.25;

            default:
                return 1.05;
        }
    }
}