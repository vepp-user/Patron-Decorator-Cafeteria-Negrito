package programa011;
public class TostadoNegro extends Cafe {

    public TostadoNegro() {
        descripcion = "Cafe Tostado Negro";
    }

    @Override
    public double costo() {

        switch (tamano) {

            case MEDIANO:
                return 1.09;

            case GRANDE:
                return 1.19;

            default:
                return 0.99;
        }
    }
}
