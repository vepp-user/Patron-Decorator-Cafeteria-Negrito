package programa011;
public class Moca extends ComplementoDecorator {

    private Cafe cafe;

    public Moca(Cafe cafe) {
        this.cafe = cafe;
    }

    @Override
    public String getDescripcion() {
        return cafe.getDescripcion() + ", Moca";
    }

    @Override
    public Tamano getTamano() {
        return cafe.getTamano();
    }

    @Override
    public double costo() {

        double precio;

        switch (getTamano()) {

            case MEDIANO:
                precio = 0.25;
                break;

            case GRANDE:
                precio = 0.30;
                break;

            default:
                precio = 0.20;
        }

        return cafe.costo() + precio;
    }
}