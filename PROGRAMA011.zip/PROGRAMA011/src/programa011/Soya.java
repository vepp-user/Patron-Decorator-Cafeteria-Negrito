package programa011;
public class Soya extends ComplementoDecorator {

    private Cafe cafe;

    public Soya(Cafe cafe) {
        this.cafe = cafe;
    }

    @Override
    public String getDescripcion() {
        return cafe.getDescripcion() + ", Soya";
    }

    @Override
    public Tamano getTamano() {
        return cafe.getTamano();
    }

    @Override
    public double costo() {

        double precio;

        switch (getTamano()) {

            case MEDIANO:
                precio = 0.20;
                break;

            case GRANDE:
                precio = 0.25;
                break;

            default:
                precio = 0.15;
        }

        return cafe.costo() + precio;
    }
}
