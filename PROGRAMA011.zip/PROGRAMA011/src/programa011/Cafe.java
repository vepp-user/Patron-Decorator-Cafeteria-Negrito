package programa011;
public abstract class Cafe {

    protected String descripcion = "Cafe";
    protected Tamano tamano = Tamano.NORMAL;

    public String getDescripcion() {
        return descripcion;
    }

    public Tamano getTamano() {
        return tamano;
    }

    public void setTamano(Tamano tamano) {
        this.tamano = tamano;
    }

    public abstract double costo();
}
