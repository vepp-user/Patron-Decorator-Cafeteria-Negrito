package programa011;
public enum Tamano {
    NORMAL,
    MEDIANO,
    GRANDE
}
