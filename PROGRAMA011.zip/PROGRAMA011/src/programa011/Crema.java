package programa011;
public class Crema extends ComplementoDecorator {

    private Cafe cafe;

    public Crema(Cafe cafe) {
        this.cafe = cafe;
    }

    @Override
    public String getDescripcion() {
        return cafe.getDescripcion() + ", Crema";
    }

    @Override
    public Tamano getTamano() {
        return cafe.getTamano();
    }

    @Override
    public double costo() {

        double precio;

        switch (getTamano()) {

            case MEDIANO:
                precio = 0.15;
                break;

            case GRANDE:
                precio = 0.20;
                break;

            default:
                precio = 0.10;
        }

        return cafe.costo() + precio;
    }
}
